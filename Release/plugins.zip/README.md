# Cloudburst exists somewhat!
sorry it took so long or whatever, and sorry it's gonna take even longer to get a proper update

## This is a BETA
Just whatever we have developed at the time. The survivor Custodian, and a few items.
- Custodian is fully functional and networked. Absolutely feel free to reach out in the Cloudburst server https://discord.gg/MNDh59sf2N for bugs and feedback
- Items are small selection of what was there before, plus some reworks and new ones.
- All other previous content is not here.
### What happened?
I wonder if there are people who don't even know about CUM right now?  
Ages ago there were four nations that lived in harmony. Starstorm 2, Enforcer Gang, Cloudburst, and Hopoo, but everything changed when Hopoo attacked.  
Just kidding there wasn't harmony at all shit was chaos.  

Anyway there was an update that killed all mods, some of them didn't survive, one of which was Cloudburst, a content mod with a bunch of items, a survivor and a little extra content. Over the years, Enigma, the head of the project (and sole programmer) after a long time of trying to get this project back up and running (as well as being overly ambitious with adding new things) long story short ended up leaving the project.  

So here we are. A few of us (SomeoneElse, TheTimesweeper, Dotflare) got together, grabbed some of the old content, put it in a new project, and now we're releasing what we got. It's nowhere near done (except Custodian which I believe to be mostly finished) but it *exists*, which is more than we can say for the past two years almost. 

## Custodian
A [new] survivor finally back from the dead, and finally getting a full round of polish to his abilities. Let us know what you think on our discord https://discord.gg/MNDh59sf2N.
  
His gameplay involves manipulating enemies' gravity to his advantage. Use your Grav-Broom and MAID to float enemies up higher and higher, then spike them down for heavy impact damage!
- fully multiplayer compatible
- Item displays and ragdoll
- EmoteAPI

![](https://raw.githubusercontent.com/NotSomeoneElse/Cloudburst/main/Release/_readme/wyattscren.png)
![](https://raw.githubusercontent.com/NotSomeoneElse/Cloudburst/main/CloudburstUnity/Assets/Survivors/Wyatt/WyattBundle/Wyatt/Icons/texIconWyatt.png)

## Items
| Icon | Name | Description | Tier |
| - | - | - | - |
| ![](https://raw.githubusercontent.com/NotSomeoneElse/Cloudburst/main/Release/_readme/glas.png)    |Glass Harvester | Your 'Critical Strikes' deal an additional 40% damage. Breaks at low health, granting experience. |Common |
| ![](https://raw.githubusercontent.com/NotSomeoneElse/Cloudburst/main/Release/_readme/bism.png)    |Bismuth Earrings| Gain barrier on applying bleed | Rare |
| ![](https://raw.githubusercontent.com/NotSomeoneElse/Cloudburst/main/Release/_readme/fab.png)    |Fabinhoru's Dagger| Striking bleeding enemies reduces their armor. | Rare |
| ![](https://raw.githubusercontent.com/NotSomeoneElse/Cloudburst/main/Release/_readme/jape.png)    |Jape's Cloak| Gain a buff that grants armor and healing on item pickup. |Rare |
| ![](https://raw.githubusercontent.com/NotSomeoneElse/Cloudburst/main/Release/_readme/enig.png)    |Enigmatic Keycard |Chance to spawn an orb on hit that follows and shocks enemies. |Rare |

## What's next
- hopefully some housekeeping to get the project workable if other people would like to step in and do stuff
- more wyatt polish, maybe ancient scepter and all that fun stuff
- enemies if the enemy template happens

## Credits
- Enigma - original creator
- Dotflare - models textures and animation
- Box - concept and design
- f4uxx - concept and design
- Tiltedhat - concept and design
- SomeoneElse - recreating the mod. without him, this return wouldn't have happened
- TheTimesweeper - nu-custodian. without him, this return would have happened 8 months earlier
- Unknownglaze - custodian default jingle
- NAIRB - custodian stage-specific jingles
- Spanish Space Inquisition - MAID animations
- Phreel - coding and fixes

### Translations
BR Portuguese - Kauzok  
Chinese (simplified) - Meteorite1014  
French - StyleMyk  
Russian - HEXXEDUDE  

If you'd like to translate the mod to your language, see the language text files [here](https://github.com/NotSomeoneElse/Cloudburst/tree/main/Release/plugins/Language).  
Thanks to those that have and in advance to those that may!