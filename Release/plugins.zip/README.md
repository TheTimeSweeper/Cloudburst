# Cloudburst exists somewhat!
sorry it took so long or whatever, and sorry it's gonna take even longer to get a proper update

## This is a BETA
Just whatever we have developed at the time. The survivor Custodian, and a few items.
- Custodian is fully functional and networked. Absolutely feel free to reach out in the Cloudburst server https://discord.gg/MNDh59sf2N for bugs and feedback
- Items are incomplete and untested for networking, balance, bugs, or anything like that, but I be*lieve* they're working. 
  - Feel free to report in the server as well about them I suppose. 
  - You can turn them all off in the config (not individually, sorry) if there is an issue (or if you just want Custodian)
- All other previous content is not here.
### What happened?
I wonder if there are people who don't even know about CUM right now?  
Ages ago there were four nations that lived in harmony. Starstorm 2, Enforcer Gang, Cloudburst, and Hopoo, but everything changed when Hopoo attacked.  
Just kidding there wasn't harmony at all shit was chaos.  

Anyway there was an update that killed all mods, some of them didn't survive, one of which was Cloudburst, a content mod with a bunch of items, a survivor and a little extra content. Over the years, Enigma, the head of the project (and sole programmer) after a long time of trying to get this project back up and running (as well as being overly ambitious with adding new things) long story short ended up leaving the project.  

So here we are. A few of us (SomeoneElse, TheTimesweeper, Dotflare) got together, grabbed some of the old content, put it in a new project, and now we're releasing what we got. It's nowhere near done (except Custodian which I believe to be mostly finished) but it *exists*, which is more than we can say for the past two years almost. 

## Custodian
A [new] survivor finally back from the dead, and finally getting a full round of polish to his abilities. Let us know what you think on our discord https://discord.gg/MNDh59sf2N.
  
His gameplay involves manipulating enemies' gravity to his advantage. Use your Grav-Broom and MAID to float enemies up higher and higher, then spike them down for heavy impact damage!
- fully multiplayer compatible
- Item displays and ragdoll
- EmoteAPI

![](https://raw.githubusercontent.com/NotSomeoneElse/Cloudburst/main/Release/_readme/wyattscren.png)
![](https://raw.githubusercontent.com/NotSomeoneElse/Cloudburst/main/CloudburstUnity/Assets/Survivors/Wyatt/WyattBundle/Wyatt/Icons/texIconWyatt.png)

## Items
| Icon | Name | Description | Tier |
| - | - | - | - |
| ![](https://i.imgur.com/3CQySKC.png)    |Glass Harvester | Your 'Critical Strikes' deal an additional 40% damage. Breaks at low health, granting experience. |Common |
| ![](https://i.imgur.com/qk3a28Z.png)    |Bismuth Earrings| Gain barrier on applying bleed | Rare |
| ![](https://i.imgur.com/FJRILzB.png)    |Fabinhoru's Dagger| Striking bleeding enemies reduces their armor. | Rare |
| ![](https://i.imgur.com/15l7dNB.png)    |Jape's Cloak| Gain a buff that grants armor and healing on item pickup. |Rare |
| ![](https://i.imgur.com/l3m9Hqp.png)    |Enigmatic Keycard |Chance to spawn an orb on hit that follows and shocks enemies. |Rare |

## What's next
- hopefully some housekeeping to get the project workable if other people would like to step in and do stuff
- more wyatt polish, maybe ancient scepter and all that fun stuff

Realistically this may very well be the only update this mod gets in a long while. We'll see if any optimisim is in order in the coming months, but for now, enjoy

## Credits
- Enigma - original creator
- Dotflare - models textures and animation
- Box - concept and design
- f4uxx - concept and design
- Tiltedhat - concept and design
- Hyperinvox - concept and design
- SomeoneElse - recreating the mod. without him, this return wouldn't have happened
- TheTimesweeper - nu-custodian. without him, this return would have happened 8 months earlier
- Unknownglaze - custodian jingle
- Spanish Space Inquisition - MAID animations

### Translations
BR Portuguese - Kauzok

If you'd like to translate the mod to your language, see the language text files [here](https://github.com/NotSomeoneElse/Cloudburst/tree/main/Release/plugins/Language).  
Thanks to those that have and in advance to those that may!

## Changelog
`0.3.3`
- null checks galore. hopefully fixed errors from glass harvester, enigmatic keycard, and fabinhoru's dagger
- fixed bismuth earrings not properly adding barrier on applying bleed
- added Brazilian Portuguese translation (thanks Kauzok!)

`0.3.2`
- all items are now in their proper tiers
  - including broken glass harvester, removing it from the item pool
- added per-item configs

`0.3.1`
- added animations for MAID
- added config to disable jingle when activating flow
- Bismuth Earrings reworked
- Glass harvester reworked
- fixed wyatt becoming eldritch aboniation when emoting
- fixed issues with fabinhoru's dagger visuals
- fixed error caused fabinhoru's dagger and/or enigmatic keycard

`0.3.0`
- redid the whole fuckin thing.